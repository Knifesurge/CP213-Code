package cp213_Array;

public class ArrayTest_4 {

	public static void main(String[] args) {
		 int[] first = { 1, 3, 5, 7, 9 };
		 int[] second = first;

		 System.out.println("first:");

		 int count = 0;
		 for (int i : first) {
		     i *= 2;	// This DOES NOT change the contents of first
		     // Actually change the contents of first
		     //first[count++] *= 2;
		 }
		 
		 for (int i : first) {
		    System.out.println(i);
		 }
		 
		 System.out.println("second:");

		 for (int i : second) {
		    System.out.println(i);
		 }
	  }
}
