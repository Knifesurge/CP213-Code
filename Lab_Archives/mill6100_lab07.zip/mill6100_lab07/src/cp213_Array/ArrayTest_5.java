package cp213_Array;

public class ArrayTest_5 {

	public static void main(String[] args) {
		 int[] first = { 1, 3, 5, 7, 9 };
		 int[] second = first;
		 // Declare 2-D square array
		 int[][] third = new int[first.length][first.length];

		 // Is this allowed?
		 third[0] = first;
		 // Yes, it is
		 
		 System.out.println("first:");

		 for (int i = 0; i < first.length; i++) {
		     System.out.println(first[i]);
		 }

		 System.out.println("second:");

		 for (int i = 0; i < second.length; i++) {
		    System.out.println(second[i]);
		 }
		 
		 System.out.println("third:");
		 for (int[] i : third)
		 {
			 for (int j : i)
				 System.out.println(j);
			 System.out.println();
		 }
	  }

}
