package cp213_Array;

public class ArrayTest_1 {
	/**
	 * A1. Expected output:
	 * 
	 * first:
	 * 1
	 * 3
	 * 5
	 * 7
	 * 9
	 * second:
	 * 1
	 * 3
	 * 5
	 * 7
	 * 9
	 * -------------------------------------------------------------------
	 */
	/**
	 * Driver code
	 * @param args - Command-line arguments
	 */
	  public static void main(String[] args) {
		 int[] first = { 1, 3, 5, 7, 9 };
		 int[] second = first;

		 System.out.println("first:");

		 for (int i = 0; i < first.length; i++) {
		     System.out.println(first[i]);
		 }

		 System.out.println("second:");

		 for (int i = 0; i < second.length; i++) {
		    System.out.println(second[i]);
		 }
	  }
}
