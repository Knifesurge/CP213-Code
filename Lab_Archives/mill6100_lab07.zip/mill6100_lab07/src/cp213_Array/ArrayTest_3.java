package cp213_Array;

public class ArrayTest_3 {

	public static void main(String[] args) {
		 int[] first = { 1, 3, 5, 7, 9 };
		 int[] second = first;

		 System.out.println("first:");

		 for (int i = 0; i < first.length; i++)
		     first[i] *= 2;
		 
		 for (int i : first) {
			 System.out.println(i);
		 }
		 
		 System.out.println("second:");

		 // Prints out contents of second
		 for (int i : second) {
			 System.out.println(i);
		 }
	  }

}
