package cp213;
/**
 * Inherited class in simple example of inheritance / polymorphism.
 * 
 * This class defines a Road Bike by extending the Bicycle Base Class by specifying
 * the number of gears/speeds that the bike has.
 *
 * @author  Nicolas Mills
 * @version 2020-02-23
 */
public class RoadBike extends Bicycle {
	 private int max_gears;                   // Maximum number of gears on the bike.
	   	 
	 public RoadBike() {
		 this(10);                            // Default of a max. of 10 gears.
	 }
	 
	 public RoadBike(int max_gears) {         // Initialize in First gear and Stopped (speed = 0.0)
	 	super(1,0);
		this.max_gears = max_gears;
	 }
	  	 
	 @Override
	 protected void shiftUp(int nsteps)
	 {
		 // This shift will cause a high-gear chain derailment
		 if (this.getGear() + nsteps >= this.max_gears)
		 {
			 // Get the number of gears from current gear and max gears
			 int remainingGears = this.max_gears - this.getGear();
			 // Shift up the remaining number of gears
			 super.shiftUp(remainingGears);
			 // The bike will no longer be able to shift-up
			 // any further gears (will remain at max until 
			 // a shift-down is processed).
		 } else	
		 {	// This shift will not cause a high-gear chain
			// derailment
			 
			 // Call Bicycle#shiftUp as normal
			 super.shiftUp(nsteps);
		 }
	 }
	 
    @Override
	 public void print() {
		 System.out.println("Road Bike:: Number of Speeds = [" + max_gears +"]");
		 super.print();
	 }
}
